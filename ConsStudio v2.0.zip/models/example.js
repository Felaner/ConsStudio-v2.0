// const Sequelize = require('sequelize')
// const sequelize = require('../utils/database')
//
// const example = sequelize.define('Example', {
//     id: {
//         primaryKey: true,
//         autoIncrement: true,
//         allowNull: false,
//         type: Sequelize.INTEGER
//     }
// })
//
// module.exports = example