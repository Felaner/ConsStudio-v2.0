module.exports = {
    BASE_URL: 'http://localhost:3000',
    HOST: 'localhost',
    EMAIL_USER: 'kirill.deykun1@gmail.com',
    EMAIL_PASS: 'Leonardo@2801',
    EMAIL_HOST: 'smtp.gmail.com',
    EMAIL_FROM: 'kirill.deykun1@gmail.com',
    EMAIL_TO: 'kirill.deykun1@gmail.com',
    SECRET_KEY: '6LdgQJQeAAAAALCFtfTKsME1FqIm0qNAXX5KkM8h'
}